Secrets: GitHub needs only CLOUDFLARE_API_TOKEN (Workers Scripts:Edit) and CLOUDFLARE_ACCOUNT_ID.
WC_STORE_URL and RAVIO_PROXY_SECRET live ONLY in Cloudflare (`wrangler secret put`), never in GitHub or the repo.
